ỨNG DỤNG STREAMLIT — Python 3.10+

python -m pip install -r lost_sales_lab/requirements.txt
python -m streamlit run lost_sales_lab/app.py

Streamlit có HQL, Meta-HQL, FQL; bản học Mimic nằm trên website/lõi, không có lựa chọn Streamlit riêng.
Nguồn: https://github.com/lequanghuyvnkor/gong-simchi_le_experiment
